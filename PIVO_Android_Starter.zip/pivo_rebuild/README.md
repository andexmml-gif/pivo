# PIVO Android starter

Premium dark social app UI prototype built with Kotlin and Jetpack Compose. Package/application ID: `com.pivo.app`.\n

## Included in this build
- Animated brand splash
- Login/signup UI prototype
- Google sign-in button placeholder
- Home feed, stories row, sample post cards with local like state
- Bottom navigation: Home, Explore, Create, Reels, Inbox, Profile
- Reels placeholder screen and empty-state screens for other tabs

## Important
This is a UI starter, not a production social app. Authentication, Firebase database/storage, actual photo/video upload, real feed, chat, notifications, follow system, moderation, and security rules still need implementation and testing. The auth buttons currently navigate into the prototype UI only. No Firebase credentials are included.

## Open in Android Studio
Open this folder as a project. Let Gradle sync. If prompted to use a compatible JDK, choose JDK 17. Then run on a device/emulator.
