package com.pivo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Night = Color(0xFF08070B)
private val Panel = Color(0xFF15131D)
private val Violet = Color(0xFF8B5CF6)
private val Pink = Color(0xFFEC4899)
private val Muted = Color(0xFF9B97AA)
private val White = Color(0xFFF8F7FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PivoApp() }
    }
}


@Composable
private fun PivoApp() {
    var splash by remember { mutableStateOf(true) }
    var signedIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(1500); splash = false }
    MaterialTheme(colorScheme = darkColorScheme(background = Night, surface = Panel, primary = Violet)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            AnimatedContent(targetState = when { splash -> "splash"; signedIn -> "main"; else -> "auth" },
                transitionSpec = { fadeIn(tween(350)) + scaleIn(initialScale = .97f) togetherWith fadeOut(tween(220)) }, label = "appFlow") { screen ->
                when(screen) { "splash" -> SplashScreen(); "main" -> MainShell(); else -> AuthScreen(onContinue = { signedIn = true }) }
            }
        }
    }
}

@Composable
private fun SplashScreen() {
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "logoPulse")
    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0x553F1D78), Night), radius = 800f)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(112.dp).scale(pulse).clip(RoundedCornerShape(32.dp)).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) {
                Text("P", fontSize = 72.sp, fontWeight = FontWeight.Black, color = White)
            }
            Spacer(Modifier.height(22.dp))
            Text("PIVO", fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = 8.sp, color = White)
            Text("YOUR WORLD. YOUR PEOPLE.", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
        }
    }
}

@Composable
private fun AuthScreen(onContinue: () -> Unit) {
    var isLogin by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0x443B1B77), Night), radius = 850f))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 26.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(64.dp))
            BrandMark(64)
            Spacer(Modifier.height(14.dp))
            Text(if (isLogin) "Welcome back" else "Join your universe", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = White)
            Text(if (isLogin) "Your people are just a tap away." else "Create your PIVO identity.", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(34.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(4.dp)) {
                AuthTab("Log in", isLogin, Modifier.weight(1f)) { isLogin = true }
                AuthTab("Sign up", !isLogin, Modifier.weight(1f)) { isLogin = false }
            }
            Spacer(Modifier.height(22.dp))
            if (!isLogin) InputField("Username", username, { username = it }, Icons.Outlined.Person, false)
            InputField("Email address", email, { email = it }, Icons.Outlined.Email, false)
            InputField("Password", password, { password = it }, Icons.Outlined.Lock, true)
            if (isLogin) Text("Forgot password?", Modifier.align(Alignment.End).padding(top = 2.dp).clickable { }, color = Violet, fontSize = 13.sp)
            Spacer(Modifier.height(22.dp))
            GradientButton(if (isLogin) "Log in" else "Create account", onContinue)
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) { Divider(Modifier.weight(1f), color = Color(0xFF2B2736)); Text("  OR CONTINUE WITH  ", color = Muted, fontSize = 10.sp); Divider(Modifier.weight(1f), color = Color(0xFF2B2736)) }
            Spacer(Modifier.height(14.dp))
            OutlinedButton(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = White)) { Text("G", fontWeight = FontWeight.Bold, fontSize = 18.sp); Spacer(Modifier.width(12.dp)); Text("Continue with Google") }
            Spacer(Modifier.height(24.dp))
            Text("By continuing, you agree to PIVO's Terms & Privacy Policy", color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(24.dp))
        }
    }
}
@Composable private fun AuthTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(12.dp)).background(if(selected) Color(0xFF302244) else Color.Transparent).clickable(onClick).padding(vertical = 12.dp), contentAlignment = Alignment.Center) { Text(label, color = if(selected) White else Muted, fontWeight = if(selected) FontWeight.SemiBold else FontWeight.Normal) }
}
@Composable private fun InputField(label: String, value: String, onValue: (String) -> Unit, icon: ImageVector, password: Boolean) {
    OutlinedTextField(value, onValue, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp), label = { Text(label) }, leadingIcon = { Icon(icon, null, tint = Muted) }, singleLine = true, visualTransformation = if(password) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Violet, unfocusedBorderColor = Color(0xFF332D40), focusedLabelColor = Violet, unfocusedLabelColor = Muted, focusedTextColor = White, unfocusedTextColor = White, cursorColor = Violet))
}
@Composable private fun GradientButton(text: String, onClick: () -> Unit) {
    Button(onClick, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet), elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp)) { Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}
@Composable private fun BrandMark(size: Int) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape((size/3).dp)).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) { Text("P", color = White, fontWeight = FontWeight.Black, fontSize = (size*.58).sp) }
}

private enum class Tab(val title: String, val icon: ImageVector) { Home("Home", Icons.Outlined.Home), Explore("Explore", Icons.Outlined.Search), Create("Create", Icons.Outlined.AddBox), Reels("Reels", Icons.Outlined.PlayCircle), Inbox("Inbox", Icons.Outlined.ChatBubbleOutline), Profile("Profile", Icons.Outlined.Person) }
@Composable private fun MainShell() {
    var tab by remember { mutableStateOf(Tab.Home) }
    Scaffold(containerColor = Night, bottomBar = {
        NavigationBar(containerColor = Color(0xFF100E16), tonalElevation = 0.dp) {
            Tab.values().forEach { item -> NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = { Icon(item.icon, item.title) }, label = { Text(item.title, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Violet, selectedTextColor = Violet, unselectedIconColor = Muted, unselectedTextColor = Muted)) }
        }
    }) { pad -> Box(Modifier.padding(pad).fillMaxSize()) { when(tab) {
        Tab.Home -> HomeScreen(onReels = { tab = Tab.Reels })
        Tab.Explore -> SimpleScreen("Explore", "Find people, ideas and moments", Icons.Outlined.Search)
        Tab.Create -> SimpleScreen("Create", "Share a moment with your people", Icons.Outlined.AddCircle)
        Tab.Reels -> ReelsScreen()
        Tab.Inbox -> SimpleScreen("Messages", "Your conversations live here", Icons.Outlined.Chat)
        Tab.Profile -> SimpleScreen("Your profile", "Your PIVO identity starts here", Icons.Outlined.Person)
    } } }
}
@Composable private fun HomeScreen(onReels: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item { Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) { BrandMark(34); Spacer(Modifier.width(10.dp)); Text("pivo", fontSize = 26.sp, fontWeight = FontWeight.Black, color = White); Spacer(Modifier.weight(1f)); IconButton(Icons.Outlined.Notifications, "Notifications") } }
        item { StoriesRow() }
        item { Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) { Text("Your feed", fontWeight = FontWeight.Bold, fontSize = 21.sp, color = White); Spacer(Modifier.weight(1f)); Text("For you  ▾", color = Violet, fontSize = 13.sp) } }
        items(listOf("Aarav Mehta" to "Golden hour hits different ✨", "Mira Kapoor" to "Somewhere between the sky and my thoughts.", "PIVO Studio" to "Meet your people. Share your moments.")) { post -> PostCard(post.first, post.second, onReels) }
    }
}
@Composable private fun StoriesRow() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(13.dp)) {
        Story("Your story", "＋", false)
        Story("riya.v", "R", true)
        Story("dev_08", "D", true)
        Story("aanya", "A", true)
        Story("karan", "K", true)
    }
}
@Composable private fun Story(name: String, letter: String, active: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(64.dp)) {
        Box(Modifier.size(58.dp).border(2.dp, if(active) Violet else Color(0xFF34303E), CircleShape).padding(4.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF402565), Color(0xFF20152F)))), contentAlignment = Alignment.Center) { Text(letter, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(5.dp)); Text(name, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
@Composable private fun PostCard(name: String, caption: String, onReels: () -> Unit) {
    var liked by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(bottom = 18.dp).clip(RoundedCornerShape(20.dp)).background(Panel)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Avatar(name.take(1), 38); Spacer(Modifier.width(10.dp)); Column { Text(name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text("Suggested · 2h ago", color = Muted, fontSize = 10.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.MoreHoriz, null, tint = Muted) }
        Box(Modifier.fillMaxWidth().height(260.dp).background(Brush.linearGradient(listOf(Color(0xFF392458), Color(0xFF15121D), Color(0xFF712D65)))), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("✦", color = Color(0xFFC7A8FF), fontSize = 48.sp); Text("P I V O   M O M E N T", color = White, fontSize = 11.sp, letterSpacing = 2.sp) }; IconButton(onReels, Modifier.align(Alignment.BottomEnd).padding(10.dp)) { Icon(Icons.Outlined.PlayCircle, "Open reels", tint = White) } }
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton({ liked = !liked }) { Icon(if(liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null, tint = if(liked) Pink else White) }; IconButton({}) { Icon(Icons.Outlined.ChatBubbleOutline, null, tint = White) }; IconButton({}) { Icon(Icons.Outlined.Send, null, tint = White) }; Spacer(Modifier.weight(1f)); IconButton({}) { Icon(Icons.Outlined.BookmarkBorder, null, tint = White) } }
        Text(if(liked) "Liked by you and others" else "Be the first to like this", color = White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 14.dp))
        Text(caption, color = White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
        Text("View all comments", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 14.dp).padding(bottom = 12.dp))
    }
}
@Composable private fun Avatar(initial: String, size: Int) { Box(Modifier.size(size.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) { Text(initial, color = White, fontWeight = FontWeight.Bold) } }
@Composable private fun ReelsScreen() { Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF2D174E), Night, Color(0xFF401B35)))), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Outlined.PlayCircle, null, tint = White, modifier = Modifier.size(76.dp)); Text("Reels", fontSize = 28.sp, color = White, fontWeight = FontWeight.Bold); Text("Swipe to discover videos", color = Muted) }; Column(Modifier.align(Alignment.BottomEnd).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) { listOf(Icons.Outlined.FavoriteBorder, Icons.Outlined.ChatBubbleOutline, Icons.Outlined.Send).forEach { Icon(it, null, tint = White, modifier = Modifier.padding(vertical = 14.dp).size(27.dp)) } } } }
@Composable private fun SimpleScreen(title: String, subtitle: String, icon: ImageVector) { Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0x332D1A55), Night), radius = 700f)), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Violet, modifier = Modifier.size(72.dp)); Spacer(Modifier.height(18.dp)); Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 27.sp); Text(subtitle, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) } } }
@Composable private fun IconButton(icon: ImageVector, contentDescription: String) { androidx.compose.material3.IconButton(onClick = {}) { Icon(icon, contentDescription, tint = White) } }
